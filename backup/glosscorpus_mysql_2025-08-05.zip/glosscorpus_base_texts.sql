-- MySQL dump 10.13  Distrib 8.0.36, for Linux (x86_64)
--
-- Host: localhost    Database: glosscorpus
-- ------------------------------------------------------
-- Server version	8.0.42-0ubuntu0.24.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `base_texts`
--

DROP TABLE IF EXISTS `base_texts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `base_texts` (
  `recordID` int NOT NULL AUTO_INCREMENT,
  `author` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `title` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `short_ref` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `slug` varchar(30) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `source_info` varchar(1000) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `source_credit` varchar(1000) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `seg_desc` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `publish` tinyint(1) NOT NULL DEFAULT '1',
  `about` varchar(3000) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`recordID`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `base_texts`
--

LOCK TABLES `base_texts` WRITE;
/*!40000 ALTER TABLE `base_texts` DISABLE KEYS */;
INSERT INTO `base_texts` VALUES (1,'Priscian','Ars grammatica','Priscian','priscian','ed. Martin Hertz in Heinrich Keil (ed.), <title>Grammatici Latini</title> (6 vols, Leipzig, 1855–80), vols II–III.','Text made available from the Corpus Grammaticorum Latinorum project (with thanks to Alessandro Garcea).','Segmented by volume, page and line in GL.',1,'The Latin grammarian Priscian wrote his magisterial <i>Ars grammatica</i> at Constantinople around AD 527. \nHis work is the most exhaustive compendium of information on Latin (and Greek) language and \nliterature to survive from the ancient world. There are over 50 manuscripts from ninth century\nand around 100 from the tenth, many of which are very heavily glossed.\n'),(2,'Paul','Epistles','Paul','paul','Clementine Vulgate Project (public domain), based mainly on edition by A. Colunga and L. Turrado (La Editorial Católica, Madrid, 1946) (see http://vulsearch.sourceforge.net).','','Segmented by chapter and verse.',1,NULL),(3,'Anon.','Psalms','Psalms','psalms','Gallican text from Clementine Vulgate Project (public domain), based mainly on edition by A. Colunga and L. Turrado (La Editorial Católica, Madrid, 1946) (see http://vulsearch.sourceforge.net).',NULL,'Segmented by Psalm number (Vulgate numbering) and line.',0,NULL),(4,'Anon.','Commentary on the Psalms','C301 inf.','psalms-comm','Based on <i>Thesaurus Palaeohibernicus</i> I, 7–483, rev. by Aaron Griffith (cf. edition by L. De Coninck, CCSL 88a, 1977).',NULL,'Segmented following <i>Thes. Pal.</i>',0,NULL),(5,'Óengus mac Óengobann','Félire Óenguso','Félire','felire','Stokes, Whitley. 1905. <title>Félire Óengusso Céli Dé: The Martyrology of Oengus the Culdee</title>. London: Dublin Institute for Advanced Studies.','Digital edition prepared by Nike Stam.','Segmented by stanza, one for each day of the calendar.',1,'The <i>Félire Óengusso</i> (Martyrology of Oengus)\nis the first extant vernacular martyrology from Ireland.\nIt is a verse calendar commemorating the feasts of Irish and other saints,\nwith one quatrain for every day of the year.\nThe text was written between 797 and 808.\n\n\n'),(6,'Isidore of Seville','Etymologiae, book 1','Isidore I','isidore','ed. W.M. Lindsay, <title>Isidori Hispalensis episcopi Etymologiarum sive Originum libri XX</title> (2 vols., Oxford, 1911).','Digital text taken from The Latin Library, at: http://www.thelatinlibrary.com/isidore.html (prepared by William L. Carey and Angus Graham).','The division into books, chapters, and chapter sections follows the division of Lindsay\'s edition.',1,NULL),(7,'Ælfric of Eynsham','Glossary','ÆGl','aelfric','ed. Julius Zupitza, <i>Ælfrics Grammatik und Glossar</i>, Erste Abteilung: Text und Varianten, Sammlung Englischer Denkmäler in kritischen Ausgaben, I (Berlin, Weidmannsche Buchhandlung, 1880).','Text made available from the <i>Dictionary of Old English Corpus</i> (with thanks to Stephen Pelle).','Cited by page and line no. following ed.',0,NULL),(8,'Josephus','Antiquities','Josephus, Ant.','josephus','Flavius Josephus (Latin trans.), <i>Antiquities</i>, book/chapter, eds. R.M. Pollard, J. Timmermann, J. di Gregorio, M. Laprade, and J.-F. Aubé-Pronce, 2013-2019','Transcription made available by the kind permission of **Richard Pollard** and checked against Bamberg Msc.Class.78 (https://zendsbb.digitale-sammlungen.de/db/0000/sbb00000114/images/))','Segmented by book and chapter number as in the Greek edition of Benedict Niese (Berlin, 6 vols. 1887-95).',0,NULL);
/*!40000 ALTER TABLE `base_texts` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-08-05 16:17:33
