-- MySQL dump 10.13  Distrib 8.0.36, for Linux (x86_64)
--
-- Host: localhost    Database: glosscorpus
-- ------------------------------------------------------
-- Server version	8.0.42-0ubuntu0.24.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `publications`
--

DROP TABLE IF EXISTS `publications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `publications` (
  `recordID` int NOT NULL AUTO_INCREMENT,
  `citation` varchar(400) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `doi` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `slug` varchar(30) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `publish` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT '1',
  `publish_date` datetime DEFAULT NULL,
  `about` varchar(3000) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  PRIMARY KEY (`recordID`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `publications`
--

LOCK TABLES `publications` WRITE;
/*!40000 ALTER TABLE `publications` DISABLE KEYS */;
INSERT INTO `publications` VALUES (1,'Rijcklof Hofman (rev. Pádraic Moran), \'Glosses on Priscian, <i>Ars grammatica</i>, in St Gall, Stiftsbibliothek, 904\'','10.71555/hofman2024','hofman2024','1','2024-12-18 00:00:00','<p>Glosses from Priscian books 1–5 were previously published in R. Hofman, <i>The Sankt Gall Priscian Commentary. Part 1</i> (2 vols, Münster, 1996). All glosses were previously published in <a href=\"http://www.stgallpriscian.ie\">St Priscian Glosses</a>, created by Pádraic Moran originally in 2010, afterwards supplemented.</p>'),(2,'(GLOSSAM work in progress)','(pending)','sweeney','1',NULL,'New transcriptions by GLOSSAM team&hellip;'),(3,'Adrian Doyle, \'Old Irish glosses on Paul\'s Epistles in Würzburg, Universitätsbibliothek, M.p.th.f. 12\'','https://doi.org/10.71555/doyle2024','doyle2024','1','2024-12-18 00:00:00','<p> The manuscript, <i>Codex Paulinus Wirziburgensis</i>, contains the Latin text of the epistles of St. Paul. Marginal and interlinear glosses explaining this text have been added to the codex in three distinguishable scribal hands. Dating from about the middle of the eighth century, these glosses comprise one of the earliest large bodies of text written in Irish. </p> <p> The purpose of this site is to make to make the Würzburg Irish glosses available in digital format. The digital text is based on the edition of the glosses available in <i>Thesaurus Palaeohibernicus, Vol. 1</i> (Stokes and Strachan, 1901). Here the editors present 3,501 glosses which include Irish content, noting however, that further glosses have apparently been lost due to the age of the manuscript, and the process of its binding. </p>'),(4,'Aaron Griffith, \'Glosses in Milan Codex Ambrosianus C 301 inf.\', in Pádraic Moran (ed.), <i>Gloss Corpus</i> &lt;<a href=\"http://www.glossing.org/glosscorpus/\">http://www.glossing.org/glosscorpus/</a>&gt; (2023). ','(pending)','griffith','1',NULL,'From the database compiled by Aaron Griffith, <i>A dictionary of the Old-Irish glosses in the Milan Codex Ambrosianus C 301 inf.</i>: <a href=\"http://www.univie.ac.at/indogermanistik/milan_glosses.htm\" target=\"_blank\">http://www.univie.ac.at/indogermanistik/milan_glosses.htm</a>.'),(5,'Nike Stam, \'Glosses on Óengus mac Óengobann, <i>Félire Óenguso</i>, in Oxford, Bodleian Library, Rawlinson B505\'','10.71555/stam2024','stam2024','1','2024-09-05 00:00:00','<p>This transcription was produced under the auspices of the NWO Vrije Competitie Project ‘<a href=\"https://medievalirishbilingualism.sites.uu.nl/publications/\">Medieval Irish Bilingualism</a>’, which ran at Utrecht University from 2012–2016.</p> <p>The transcription of the glosses was made by Nike Stam and formed the basis of her thesis ‘<a href=\"https://www.lotpublications.nl/a-typology-of-code-switching-in-the-commentary-to-the-f%C3%A9lire-%C3%B3engusso\">A Typology of Code-Switching in the Commentary to the <i>Félire Óengusso</i></a>’, in which the <b>bilingual glosses</b> were translated and analysed. The editorial policy and the XML encoding policy are explained on pp 155–162. For the bilingual glosses and their translations, see pp 475–545. All the glosses have been marked up for language; the bilingual glosses also contain PoS tags. This XML-file is Open Access and available upon request.</p> <p>Mike Olson (Emerging Standards Project) and Martijn van der Klis (Digital Humanities Utrecht University) created a framework for the XML editor oXygen that was used during the project, which is downloadable via <a href=\"https://github.com/odaata/HisTEI/tree/master/frameworks\">github</a>. Similarly, a Python script developed by Martijn van der Klis to extract glosses from the database may be found on <a href=\"https://github.com/odaata/HisTEI/tree/master/python\">github</a>.</p> <p>This online publication presents all glosses on the months January–December, including the monolingual Irish and Latin glosses. <b>Note, however, that these monolingual glosses have not been translated or analysed, and that they are therefore more likely to contain transcription errors.</b> As these glosses have not been published elsewhere and as the manuscript <a href=\"https://medieval.bodleian.ox.ac.uk/catalog/manuscript_8070\">Rawlinson B505</a> has not been digitized yet, it is hoped that they may provide an initial steppingstone for those interested in the study of the Commentary to the <i>Félire Óengusso</i>. </p> <p>The aim of this publication is to create a ‘live’ edition, which is open to corrections and additions. Nike Stam welcomes any corrections: <a href=\"mailto:n.stam@uu.nl\">n.stam@uu.nl</a>. As it stands now, the preface, prologue and epilogue are excluded, as are any potential glosses that they contain, and Nike Stam hopes to continue work on this at a later stage. </p>'),(6,'Evina Stein, \'Glosses on Isidore, <i>Etymologiae</i>, book 1\'','https://doi.org/10.71555/stein2024','stein2024','1','2024-12-18 00:00:00','<p>The glosses to the Etymologiae were transcribed as a part of the NWO VENI project \'<a href=\"https://innovatingknowledge.nl/\">Innovating Knowledge: Isidore\'s Etymologiae in the Carolingian Period</a>\' (VENI project 275-50-016) carried out at the Huygens Institute in Amsterdam in 2018-2021. </p> <p>The glosses to the first book of the Etymologiae are also published separately as E. Steinova and P. Boot, <i>The glosses to the first book of the Etymologiae of Isidore of Seville: a digital scholarly edition</i>, Huygens Institute: Amsterdam, 2021, at: <a href=\"https://db.innovatingknowledge.nl/edition\">https://db.innovatingknowledge.nl/edition</a>. The editorial standardisation and treatment are discussed in the introductory sections of the digital edition.</p> <p>The XML encoding of these glosses is described in E. Steinova and P. Boot, \'<a href=\"https://osf.io/preprints/osf/7auxz\">Editing Glosses as Networks: Exploring the Explorative Edition</a>\', in: <i>A Companion to Digital Editing Methods</i>, ed. E. Bleeker et al., forthcoming.</p> <p>The collection of glosses and layers of glossing in individual manuscripts, including the glossing hands, are analysed in E. Steinova, \'Annotation of the Etymologiae of Isidore of Seville in Its Early Medieval Context\', <i>ALMA</i> 78 (2020), 5–81.</p> <p>The network-based analysis and visualisation of the glosses to the first book of the Etymologiae are discussed in E. Stein, \'<a href=\"https://jhnr.net/articles/10.25517/jhnr.v9i1.198\">Parallel Glosses, Shared Glosses, and Gloss Clustering: Can Network-Based Approach Help Us to Understand Organic Corpora of Glosses?</a>\', <i>JHNR</i> 9 (2023), 36–100.</p> <p>An Excel datasheet with the glosses to the first book of the Etymologiae is published on Zenodo at: <a href=\"https://zenodo.org/records/5767868\">https://zenodo.org/records/5767868</a>.</p>'),(7,'Heather Pagan &amp; Annina Seiler, \'Glosses on Ælfric of Eynsham, <i>Glossary</i>\', in Pádraic Moran (ed.), <i>Gloss Corpus</i> &lt;<a href=\"http://www.glossing.org/glosscorpus/\">http://www.glossing.org/glosscorpus/</a>&gt; (2023).','(pending)','pagan-seiler','1',NULL,''),(8,'Anthony Ellis & Judith Mania, \'Glosses on Josephus, <i>Antiquities</i>\', in Pádraic Moran (ed.), <i>Gloss Corpus</i> &lt;<a href=\"http://www.glossing.org/glosscorpus/\">http://www.glossing.org/glosscorpus/</a>&gt; (2023).','(pending)','ellis-mania','1',NULL,NULL);
/*!40000 ALTER TABLE `publications` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-08-05 16:17:33
