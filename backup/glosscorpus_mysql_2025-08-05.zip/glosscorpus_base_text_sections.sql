-- MySQL dump 10.13  Distrib 8.0.36, for Linux (x86_64)
--
-- Host: localhost    Database: glosscorpus
-- ------------------------------------------------------
-- Server version	8.0.42-0ubuntu0.24.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `base_text_sections`
--

DROP TABLE IF EXISTS `base_text_sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `base_text_sections` (
  `recordID` int NOT NULL AUTO_INCREMENT,
  `base_textID` int NOT NULL,
  `ref` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `title` varchar(60) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `order_index` int DEFAULT NULL,
  PRIMARY KEY (`recordID`)
) ENGINE=InnoDB AUTO_INCREMENT=319 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `base_text_sections`
--

LOCK TABLES `base_text_sections` WRITE;
/*!40000 ALTER TABLE `base_text_sections` DISABLE KEYS */;
INSERT INTO `base_text_sections` VALUES (1,1,'0','Praefatio',1),(2,1,'1','I. De uoce, de littera',2),(3,1,'2','II. De syllaba, de dictione, de oratione, de nomine, etc.',3),(4,1,'3','III. De comparatione, de superlativo, de diminutivo',4),(5,1,'4','IV. De denominatiuis',5),(6,1,'5','V. De generibus, de numeris, de figuris, de casu',6),(7,1,'6','VI. De nominatiuo et genetiuo casu',7),(8,1,'7','VII. De ceteris casibus',8),(9,1,'8','VIII. De uerbo',9),(10,1,'9','IX. De generali uerbi declinatione',10),(11,1,'10','X. De praeterito perfecto tertiae coniugationis',11),(12,1,'11','XI. De participio',12),(13,1,'12','XII. De pronomine',13),(14,1,'13','XIII. De casibus [pronominum]',14),(15,1,'14','XIV. De praepositione',15),(16,1,'15','XV. De aduerbio, de interiectione',16),(17,1,'16','XVI. De coniunctione',17),(18,1,'17','XVII. De constructione',18),(19,1,'18','XVIII. De constructione',19),(31,2,'Titus','ad Titum',12),(34,3,'1','Psalm 1',1),(35,3,'2','Psalm 2',2),(36,3,'3','Psalm 3',3),(37,3,'4','Psalm 4',4),(38,3,'5','Psalm 5',5),(39,3,'6','Psalm 6',6),(40,3,'7','Psalm 7',7),(41,3,'8','Psalm 8',8),(42,3,'9','Psalm 9',9),(43,3,'10','Psalm 10',10),(44,3,'11','Psalm 11',11),(45,3,'12','Psalm 12',12),(46,3,'13','Psalm 13',13),(47,3,'14','Psalm 14',14),(48,3,'15','Psalm 15',15),(49,3,'16','Psalm 16',16),(50,3,'17','Psalm 17',17),(51,3,'18','Psalm 18',18),(52,3,'19','Psalm 19',19),(53,3,'20','Psalm 20',20),(54,3,'21','Psalm 21',21),(55,3,'22','Psalm 22',22),(56,3,'23','Psalm 23',23),(57,3,'24','Psalm 24',24),(58,3,'25','Psalm 25',25),(59,3,'26','Psalm 26',26),(60,3,'27','Psalm 27',27),(61,3,'28','Psalm 28',28),(62,3,'29','Psalm 29',29),(63,3,'30','Psalm 30',30),(64,3,'31','Psalm 31',31),(65,3,'32','Psalm 32',32),(66,3,'33','Psalm 33',33),(67,3,'34','Psalm 34',34),(68,3,'35','Psalm 35',35),(69,3,'36','Psalm 36',36),(70,3,'37','Psalm 37',37),(71,3,'38','Psalm 38',38),(72,3,'39','Psalm 39',39),(73,3,'40','Psalm 40',40),(74,3,'41','Psalm 41',41),(75,3,'42','Psalm 42',42),(76,3,'43','Psalm 43',43),(77,3,'44','Psalm 44',44),(78,3,'45','Psalm 45',45),(79,3,'46','Psalm 46',46),(80,3,'47','Psalm 47',47),(81,3,'48','Psalm 48',48),(82,3,'49','Psalm 49',49),(83,3,'50','Psalm 50',50),(84,3,'51','Psalm 51',51),(85,3,'52','Psalm 52',52),(86,3,'53','Psalm 53',53),(87,3,'54','Psalm 54',54),(88,3,'55','Psalm 55',55),(89,3,'56','Psalm 56',56),(90,3,'57','Psalm 57',57),(91,3,'58','Psalm 58',58),(92,3,'59','Psalm 59',59),(93,3,'60','Psalm 60',60),(94,3,'61','Psalm 61',61),(95,3,'62','Psalm 62',62),(96,3,'63','Psalm 63',63),(97,3,'64','Psalm 64',64),(98,3,'65','Psalm 65',65),(99,3,'66','Psalm 66',66),(100,3,'67','Psalm 67',67),(101,3,'68','Psalm 68',68),(102,3,'69','Psalm 69',69),(103,3,'70','Psalm 70',70),(104,3,'71','Psalm 71',71),(105,3,'72','Psalm 72',72),(106,3,'73','Psalm 73',73),(107,3,'74','Psalm 74',74),(108,3,'75','Psalm 75',75),(109,3,'76','Psalm 76',76),(110,3,'77','Psalm 77',77),(111,3,'78','Psalm 78',78),(112,3,'79','Psalm 79',79),(113,3,'80','Psalm 80',80),(114,3,'81','Psalm 81',81),(115,3,'82','Psalm 82',82),(116,3,'83','Psalm 83',83),(117,3,'84','Psalm 84',84),(118,3,'85','Psalm 85',85),(119,3,'86','Psalm 86',86),(120,3,'87','Psalm 87',87),(121,3,'88','Psalm 88',88),(122,3,'89','Psalm 89',89),(123,3,'90','Psalm 90',90),(124,3,'91','Psalm 91',91),(125,3,'92','Psalm 92',92),(126,3,'93','Psalm 93',93),(127,3,'94','Psalm 94',94),(128,3,'95','Psalm 95',95),(129,3,'96','Psalm 96',96),(130,3,'97','Psalm 97',97),(131,3,'98','Psalm 98',98),(132,3,'99','Psalm 99',99),(133,3,'100','Psalm 100',100),(134,3,'101','Psalm 101',101),(135,3,'102','Psalm 102',102),(136,3,'103','Psalm 103',103),(137,3,'104','Psalm 104',104),(138,3,'105','Psalm 105',105),(139,3,'106','Psalm 106',106),(140,3,'107','Psalm 107',107),(141,3,'108','Psalm 108',108),(142,3,'109','Psalm 109',109),(143,3,'110','Psalm 110',110),(144,3,'111','Psalm 111',111),(145,3,'112','Psalm 112',112),(146,3,'113','Psalm 113',113),(147,3,'114','Psalm 114',114),(148,3,'115','Psalm 115',115),(149,3,'116','Psalm 116',116),(150,3,'117','Psalm 117',117),(151,3,'118','Psalm 118',118),(152,3,'119','Psalm 119',119),(153,3,'120','Psalm 120',120),(154,3,'121','Psalm 121',121),(155,3,'122','Psalm 122',122),(156,3,'123','Psalm 123',123),(157,3,'124','Psalm 124',124),(158,3,'125','Psalm 125',125),(159,3,'126','Psalm 126',126),(160,3,'127','Psalm 127',127),(161,3,'128','Psalm 128',128),(162,3,'129','Psalm 129',129),(163,3,'130','Psalm 130',130),(164,3,'131','Psalm 131',131),(165,3,'132','Psalm 132',132),(166,3,'133','Psalm 133',133),(167,3,'134','Psalm 134',134),(168,3,'135','Psalm 135',135),(169,3,'136','Psalm 136',136),(170,3,'137','Psalm 137',137),(171,3,'138','Psalm 138',138),(172,3,'139','Psalm 139',139),(173,3,'140','Psalm 140',140),(174,3,'141','Psalm 141',141),(175,3,'142','Psalm 142',142),(176,3,'143','Psalm 143',143),(177,3,'144','Psalm 144',144),(178,3,'145','Psalm 145',145),(179,3,'146','Psalm 146',146),(180,3,'147','Psalm 147',147),(181,3,'148','Psalm 148',148),(182,3,'149','Psalm 149',149),(183,3,'150','Psalm 150',150),(184,4,'jer_gall','Jerome\'s preface to Gallicanum',10),(185,4,'ps-bede','Pseudo-Bede\'s preface',20),(186,4,'jer_heb','Jerome\'s preface to Hebraicum',30),(187,4,'ps001-010','Comm. on Psalms 1–10',40),(188,4,'ps011-020','Comm. on Psalms 11–20',50),(189,4,'ps021-040','Comm. on Psalms 21–40',60),(190,4,'ps041-070','Comm. on Psalms 41–70',70),(191,4,'ps071-090','Comm. on Psalms 71–90',80),(192,4,'ps091-150','Comm. on Psalms 91–150',90),(193,5,'jan','January',1),(194,5,'feb','February',2),(195,5,'mar','March',3),(196,5,'apr','April',4),(197,5,'may','May',5),(198,5,'jun','June',6),(199,5,'jul','July',7),(200,5,'aug','August',8),(201,5,'sep','September',9),(202,5,'oct','October',10),(203,5,'nov','November',11),(204,5,'dec','December',12),(250,7,'0','NOMINA',1),(251,7,'1','NOMINA MEMBRORVM',2),(252,7,'3','NOMINA AVIVM',3),(253,7,'4','NOMINA PISCIVM',4),(254,7,'5','NOMINA FERARVM',5),(255,7,'5b','NOMINA HERBARVM',6),(256,7,'6','NOMINA ARBORVM',7),(257,7,'8','NOMINA DOMORVM',8),(259,8,'1','Book 1',1),(262,2,'Rom.','ad Romanos',1),(263,2,'1 Cor.','ad Corinthos I',2),(264,2,'2 Cor.','ad Corinthos II',3),(265,2,'Gal.','ad Galatas',4),(266,2,'Eph.','ad Ephesios',5),(267,2,'Phil.','ad Philippenses',6),(268,2,'Col.','ad Colossenses',7),(269,2,'1 Thes.','ad Thessalonicenses I',8),(270,2,'2 Thes.','ad Thessalonicenses II',9),(271,2,'1 Tim.','ad Timotheum I',10),(272,2,'2 Tim.','ad Timotheum II',11),(273,2,'Phi.','ad Philemonem',13),(274,2,'Heb.','ad Hebræos',14),(275,6,'1.I','1.I DE DISCIPLINA ET ARTE.',1),(276,6,'1.II','1.II DE SEPTEM LIBERALIBVS DISCIPLINIS.',2),(277,6,'1.III','1.III DE LITTERIS COMMVNIBVS.',3),(278,6,'1.IV','1.IV DE LITTERIS LATINIS.',4),(279,6,'1.V','1.V DE GRAMMATICA.',5),(280,6,'1.VI','1.VI DE PARTIBVS ORATIONIS.',6),(281,6,'1.VII','1.VII DE NOMINE.',7),(282,6,'1.VIII','1.VIII DE PRONOMINE.',8),(283,6,'1.IX','1.IX DE VERBO.',9),(284,6,'1.X','1.X DE ADVERBIO.',10),(285,6,'1.XI','1.XI DE PARTICIPIO.',11),(286,6,'1.XII','1.XII DE CONIVNCTIONE.',12),(287,6,'1.XIII','1.XIII DE PRAEPOSITIONE.',13),(288,6,'1.XIV','1.XIV DE INTERIECTIONE.',14),(289,6,'1.XV','1.XV DE LITTERIS APVD GRAMMATICOS.',15),(290,6,'1.XVI','1.XVI DE SYLLABA.',16),(291,6,'1.XVII','1.XVII DE PEDIBVS.',17),(292,6,'1.XVIII','1.XVIII DE ACCENTIBVS.',18),(293,6,'1.XIX','1.XIX DE FIGVRIS ACCENTVVM.',19),(294,6,'1.XX','1.XX DE POSITVRIS.',20),(295,6,'1.XXI','1.XXI DE NOTIS SENTENTIARVM.',21),(296,6,'1.XXII','1.XXII DE NOTIS VVLGARIBVS.',22),(297,6,'1.XXIII','1.XXIII DE NOTIS IVRIDICIS.',23),(298,6,'1.XXIV','1.XXIV DE NOTIS MILITARIBVS.',24),(299,6,'1.XXV','1.XXV DE NOTIS LITTERARVM.',25),(300,6,'1.XXVI','1.XXVI DE NOTIS DIGITORVM.',26),(301,6,'1.XXVII','1.XXVII DE ORTHOGRAPHIA.',27),(302,6,'1.XXVIII','1.XXVIII DE ANALOGIA.',28),(303,6,'1.XXIX','1.XXIX DE ETYMOLOGIA.',29),(304,6,'1.XXX','1.XXX DE GLOSSIS.',30),(305,6,'1.XXXI','1.XXXI DE DIFFERENTIIS.',31),(306,6,'1.XXXII','1.XXXII DE BARBARISMO.',32),(307,6,'1.XXXIII','1.XXXIII DE SOLOECISMIS.',33),(308,6,'1.XXXIV','1.XXXIV DE VITIIS.',34),(309,6,'1.XXXV','1.XXXV DE METAPLASMIS.',35),(310,6,'1.XXXVI','1.XXXVI DE SCHEMATIBVS.',36),(311,6,'1.XXXVII','1.XXXVII DE TROPIS.',37),(312,6,'1.XXXVIII','1.XXXVIII DE PROSA.',38),(313,6,'1.XXXIX','1.XXXIX DE METRIS.',39),(314,6,'1.XL','1.XL DE FABVLA.',40),(315,6,'1.XLI','1.XLI DE HISTORIA.',41),(316,6,'1.XLII','1.XLII DE PRIMIS AVCTORIBVS HISTORIARVM.',42),(317,6,'1.XLIII','1.XLIII DE VTILITATE HISTORIAE.',43),(318,6,'1.XLIV','1.XLIV DE GENERIBVS HISTORIAE.',44);
/*!40000 ALTER TABLE `base_text_sections` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-08-05 16:17:33
